ALTER TABLE `#__jcomments` CHANGE `path` `path` VARCHAR(190) NOT NULL DEFAULT '';
