Plugins for JComments and other components.

| Plugin file | Description |
|-------------|-------------|
| [plg_jcomments_avatar_4.2.4.zip](https://github.com/exstreme/Jcomments-4/raw/master/build/plugins/plg_jcomments_avatar_4.2.4.zip) | Plugin for JComments to support user avatars from 3rd party extensions. |
| [plug_cbjcomments_v2.7.zip](https://github.com/exstreme/Jcomments-4/raw/master/build/plugins/plug_cbjcomments_v2.7.zip)           | Displays user comments and allows to comment user's profile |
